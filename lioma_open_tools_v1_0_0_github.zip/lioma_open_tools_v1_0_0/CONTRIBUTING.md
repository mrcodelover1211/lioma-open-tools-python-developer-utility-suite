# Contributing

Thanks for helping with Lioma Open Tools!

- Keep transformations local-first unless a network feature is clearly marked and explicitly user initiated.
- Add unit tests for core utility behavior.
- Keep utilities non-destructive by default.
- Document security limitations, especially for tokens, hashes, and file inspection.
- Never include credentials, real tokens, or private user files in issues or pull requests.

For bugs, include OS, Python version, steps to reproduce, expected behavior, actual behavior, and a sanitized traceback.
