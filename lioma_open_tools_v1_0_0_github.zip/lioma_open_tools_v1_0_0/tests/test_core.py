import hashlib, tempfile, unittest
from pathlib import Path
from lioma_open_tools import core
class CoreTests(unittest.TestCase):
    def test_hash(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"x";p.write_bytes(b"hello")
            self.assertEqual(core.hash_file(p),hashlib.sha256(b"hello").hexdigest())
    def test_json_format(self):
        self.assertEqual(core.format_json('{"x":1}',2),'{\n  "x": 1\n}')
    def test_base64(self):
        self.assertEqual(core.base64_decode(core.base64_encode("Lioma")),"Lioma")
    def test_uuid_count(self): self.assertEqual(len(core.make_uuids(3).splitlines()),3)
    def test_timestamp(self): self.assertEqual(core.timestamp_convert("0"),"1970-01-01T00:00:00Z")
    def test_color(self): self.assertIn("RGB: 39, 93, 173",core.color_convert("#275dad"))
    def test_jwt_decode_warning(self):
        import base64,json
        def part(x): return base64.urlsafe_b64encode(json.dumps(x).encode()).decode().rstrip("=")
        token=part({"alg":"none"})+"."+part({"sub":"123"})+".sig"
        out=core.decode_jwt(token)
        self.assertIn("SIGNATURE NOT VERIFIED",out)
    def test_diff(self): self.assertIn("-old",core.text_diff("old\n","new\n"))
if __name__=="__main__":unittest.main()
