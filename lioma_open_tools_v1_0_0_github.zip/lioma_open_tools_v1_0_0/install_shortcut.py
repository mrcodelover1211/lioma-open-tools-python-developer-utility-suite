"""Create or update a Windows desktop shortcut for Lioma Open Tools.

Run this script from the extracted project folder with Python 3.10+:
    py install_shortcut.py

No administrator permissions or third-party packages are required.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
SHORTCUT_NAME = "Lioma Open Tools.lnk"


def _ps_quote(value: str) -> str:
    """Quote a string safely for a PowerShell single-quoted literal."""
    return "'" + value.replace("'", "''") + "'"


def find_pythonw() -> Path:
    """Prefer pythonw.exe so launching the app does not open a console."""
    executable = Path(sys.executable).resolve()
    if executable.name.lower() == "pythonw.exe":
        return executable
    candidate = executable.with_name("pythonw.exe")
    if candidate.exists():
        return candidate
    # Some Python distributions expose pythonw.exe on PATH even if it is not
    # beside the interpreter used to run this script.
    on_path = shutil.which("pythonw.exe") or shutil.which("pythonw")
    if on_path:
        return Path(on_path).resolve()
    # Last-resort fallback: still create a working shortcut, but a console may
    # appear when it is launched.
    return executable


def create_shortcut() -> Path:
    if os.name != "nt":
        raise OSError("Desktop shortcut creation is supported on Windows only.")

    desktop = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Desktop"
    # Respect redirected/OneDrive desktops when Windows exposes the known path.
    known_desktop = os.environ.get("OneDrive")
    if known_desktop and (Path(known_desktop) / "Desktop").is_dir():
        desktop = Path(known_desktop) / "Desktop"
    if not desktop.is_dir():
        desktop.mkdir(parents=True, exist_ok=True)

    shortcut = desktop / SHORTCUT_NAME
    pythonw = find_pythonw()
    icon = APP_DIR / "lioma_open_tools.ico"

    script = "\n".join([
        "$ErrorActionPreference = 'Stop'",
        "$shell = New-Object -ComObject WScript.Shell",
        f"$shortcut = $shell.CreateShortcut({_ps_quote(str(shortcut))})",
        f"$shortcut.TargetPath = {_ps_quote(str(pythonw))}",
        "$shortcut.Arguments = '-m lioma_open_tools'",
        f"$shortcut.WorkingDirectory = {_ps_quote(str(APP_DIR))}",
        "$shortcut.Description = 'Launch Lioma Open Tools'",
        f"$shortcut.IconLocation = {_ps_quote(str(icon) + ',0') if icon.is_file() else _ps_quote(str(pythonw) + ',0')}",
        "$shortcut.Save()",
    ])
    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if not powershell:
        raise RuntimeError("Windows PowerShell was not found. It is normally included with Windows.")

    # -EncodedCommand expects UTF-16LE Base64. This avoids quoting problems in
    # paths containing spaces, apostrophes, or non-English characters.
    import base64
    encoded = base64.b64encode(script.encode("utf-16le")).decode("ascii")
    result = subprocess.run(
        [powershell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "PowerShell could not create the shortcut.").strip()
        raise RuntimeError(detail)
    return shortcut


def main() -> int:
    try:
        shortcut = create_shortcut()
    except Exception as exc:
        print(f"Could not create the desktop shortcut: {exc}", file=sys.stderr)
        return 1
    print(f"Desktop shortcut created or updated:\n{shortcut}")
    if Path(sys.executable).name.lower() != "pythonw.exe" and find_pythonw() == Path(sys.executable).resolve():
        print("Note: pythonw.exe was not found, so the shortcut may open a console window.")
    print("You can now launch Lioma Open Tools from your desktop.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
