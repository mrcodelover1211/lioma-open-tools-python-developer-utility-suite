## Summary

## Testing
- [ ] Unit tests pass
- [ ] Manually tested affected GUI feature

## Checklist
- [ ] No secrets or private data included
- [ ] Docs updated
- [ ] Tests added where practical
