---
name: Bug report
about: Report a reproducible issue
title: "[Bug]: "
labels: bug
---

**OS / Python version:**

**Steps to reproduce:**
1.
2.

**Expected behavior:**

**Actual behavior:**

**Sanitized error output:**
Remove secrets, private paths, tokens, and personal data before posting.
