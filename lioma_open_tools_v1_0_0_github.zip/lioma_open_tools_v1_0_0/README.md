# Lioma Open Tools

A free, open-source, local-first desktop toolbox for everyday developer chores. One normal desktop app, a searchable tool list, and settings instead of a browser tab graveyard.

**Version:** 1.0.0 · **License:** MIT · **Status:** Community release

## Tools included

### Data and encoding
- **JSON Formatter** — pretty-print, minify, and validate JSON with Python's parser.
- **Base64 / URL** — Base64 and Base64URL encode/decode, URL component encode/decode.
- **HTML Entities** — escape and unescape HTML entities.

### Text and debugging
- **Text Diff** — compare two text snippets using a unified diff.
- **Text Case** — uppercase, lowercase, title/sentence case, snake_case, kebab-case, camelCase.
- **Regex Tester** — test Python regular expressions with `i`, `m`, and `s` flags, match offsets, and groups.
- **Text Encoding** — convert text file encodings without overwriting the source.

### Identifiers, time, and design
- **UUID Generator** — generate UUID v4 identifiers in batches.
- **Timestamp Converter** — Unix seconds/milliseconds to UTC ISO time and ISO time back to epoch.
- **Color Converter** — HEX to RGB and HSL.
- **URL Parser** — inspect scheme, host, port, path, fragment, and query parameters.

### File and token inspection
- **Hash & File Inspector** — SHA-256, SHA-512, SHA-1, MD5, common file signatures, MIME guess, extension mismatch warnings.
- **File Info** — size, path, modified time, and SHA-256.
- **JWT Inspector** — decode JWT header and payload locally for inspection only. **It does not verify signatures.**

### App experience
- Searchable navigation, Home page, Settings button, Light/Dark theme, font size setting, About page, copy-to-clipboard actions.

## Getting started

Open [COMMANDS.md](COMMANDS.md) for step-by-step setup, launch, test, Windows desktop shortcut, and GitHub publishing instructions.

## Install / run

Requires Python 3.10+ and Tkinter. No third-party Python packages are required.

```powershell
py -m lioma_open_tools
```

On Windows, create a desktop shortcut with `py install_shortcut.py`.

Run tests:

```powershell
py -m unittest discover -s tests -v
```

## Privacy and safety

- Processing stays on your computer. This version makes no network requests and has no telemetry.
- Do not paste real passwords, API keys, private tokens, or production secrets into any debugging tool unless you understand the consequences. The JWT tool is local, but its output may contain sensitive claims.
- JWT decoding is **not** JWT validation. The signature is not verified, and claims must not be trusted based on decoded output.
- File signature checks are heuristic and are **not antivirus**.
- MD5 and SHA-1 are included for compatibility, not recommended for collision-resistant security checks.
- Text Diff uses the text pasted into its inputs. Text Encoding writes to a separate destination.

## Roadmap

- [ ] Persist settings between launches
- [ ] Add YAML, XML, SQL and CSV formatters/converters
- [ ] Add JSON diff, JSON-to-CSV and JSON-to-YAML
- [ ] Add cron expression parser
- [ ] Add password / random test-data generator
- [ ] Add API request builder (network calls clearly marked and user initiated)
- [ ] Add drag-and-drop and recent tools
- [ ] Add accessible keyboard navigation and more complete dark theme styling
- [ ] Test on Windows, macOS, and Linux

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Issues and pull requests are welcome. Please remove secrets, personal paths, and private data from reports.

## License

MIT. See [LICENSE](LICENSE).
