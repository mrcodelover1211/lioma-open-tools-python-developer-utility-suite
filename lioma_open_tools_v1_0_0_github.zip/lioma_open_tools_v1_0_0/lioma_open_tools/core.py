"""Local-first core functions for Lioma Open Tools."""
from __future__ import annotations
import base64, binascii, difflib, hashlib, json, mimetypes, re, uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, unquote, urlparse, parse_qs
import colorsys

SIGNATURES = [
    (b"\x89PNG\r\n\x1a\n", "PNG image", ".png"),
    (b"\xff\xd8\xff", "JPEG image", ".jpg/.jpeg"),
    (b"GIF87a", "GIF image", ".gif"), (b"GIF89a", "GIF image", ".gif"),
    (b"BM", "BMP image", ".bmp"), (b"PK\x03\x04", "ZIP-based archive", ".zip"),
    (b"7z\xbc\xaf\x27\x1c", "7-Zip archive", ".7z"),
    (b"Rar!\x1a\x07", "RAR archive", ".rar"), (b"\x1f\x8b", "GZIP archive", ".gz"),
    (b"%PDF-", "PDF document", ".pdf"), (b"\x7fELF", "ELF executable", None),
    (b"MZ", "Windows PE/DOS executable signature", ".exe/.dll"),
    (b"ID3", "MP3 audio with ID3 tag", ".mp3"), (b"OggS", "Ogg media", ".ogg/.opus"),
    (b"fLaC", "FLAC audio", ".flac"), (b"SQLite format 3\x00", "SQLite database", ".sqlite/.db"),
    (b"\x1f\x8b", "GZIP archive", ".gz"),
]
def hash_file(path, algorithm="sha256"):
    algorithm = algorithm.lower().replace("-", "")
    if algorithm not in {"sha256","sha512","sha1","md5"}:
        raise ValueError("Supported: SHA-256, SHA-512, SHA-1, MD5")
    h=hashlib.new(algorithm)
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()
def identify_file(path):
    p=Path(path)
    with p.open("rb") as f: head=f.read(64)
    label, expected="Unknown / unrecognized signature",None
    for sig, name, ext in SIGNATURES:
        if head.startswith(sig):
            label,expected=name,ext
            if sig==b"\x1f\x8b": label="GZIP archive"
            break
    return {"name":p.name,"extension":p.suffix.lower() or "(none)","detected_type":label,
            "expected_extension":expected or "Not determined",
            "mime_guess":mimetypes.guess_type(str(p))[0] or "Unknown",
            "extension_mismatch":bool(expected and p.suffix and p.suffix.lower() not in expected.split("/")),
            "note":"Signature checks are heuristic, not antivirus."}
def file_info(path):
    p=Path(path); s=p.stat()
    return {"Name":p.name,"Path":str(p.resolve()),"Extension":p.suffix or "(none)",
            "Size (bytes)":s.st_size,"Modified":datetime.fromtimestamp(s.st_mtime).astimezone().isoformat(timespec="seconds"),
            "SHA-256":hash_file(p) if p.is_file() else "(directory)"}
def text_diff(a,b,left="left",right="right"):
    return "".join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=left,tofile=right)) or "No differences found."
def convert_encoding(source,dest,source_encoding="utf-8",dest_encoding="utf-8"):
    src,dst=Path(source),Path(dest)
    if src.resolve()==dst.resolve(): raise ValueError("Source and destination must be different files.")
    text=src.read_text(encoding=source_encoding)
    dst.write_bytes(text.encode(dest_encoding))
def format_json(text, indent=2, minify=False, sort_keys=False):
    value=json.loads(text)
    return json.dumps(value, ensure_ascii=False, sort_keys=sort_keys, separators=(",",":") if minify else None, indent=None if minify else indent)
def base64_encode(text, urlsafe=False):
    data=text.encode("utf-8")
    return (base64.urlsafe_b64encode(data) if urlsafe else base64.b64encode(data)).decode("ascii")
def base64_decode(text, urlsafe=False):
    raw=text.strip().encode("ascii")
    raw += b"="*((-len(raw))%4)
    data=(base64.urlsafe_b64decode(raw) if urlsafe else base64.b64decode(raw, validate=True))
    return data.decode("utf-8")
def url_encode(text): return quote(text, safe="")
def url_decode(text): return unquote(text)
def make_uuids(count=1):
    if not 1 <= count <= 1000: raise ValueError("Count must be between 1 and 1000.")
    return "\n".join(str(uuid.uuid4()) for _ in range(count))
def timestamp_convert(value, unit="seconds"):
    v=float(value)
    factors={"seconds":1,"milliseconds":1000}
    if unit not in factors: raise ValueError("Choose seconds or milliseconds.")
    dt=datetime.fromtimestamp(v/factors[unit], tz=timezone.utc)
    return dt.isoformat().replace("+00:00","Z")
def iso_to_timestamp(value, unit="seconds"):
    dt=datetime.fromisoformat(value.strip().replace("Z","+00:00"))
    if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
    seconds=dt.timestamp()
    return str(int(seconds if unit=="seconds" else seconds*1000))
def regex_test(pattern, text, flags=""):
    f=0
    for ch, bit in [("i",re.I),("m",re.M),("s",re.S)]: 
        if ch in flags.lower(): f|=bit
    rx=re.compile(pattern,f)
    matches=list(rx.finditer(text))
    out=[f"{len(matches)} match(es)"]
    for i,m in enumerate(matches[:500],1):
        out.append(f"{i}. {m.group(0)!r} at {m.start()}:{m.end()}")
        if m.groups(): out.append(f"   groups: {m.groups()!r}")
    if len(matches)>500: out.append("Output limited to first 500 matches.")
    return "\n".join(out)
def color_convert(value):
    v=value.strip().lstrip("#")
    if len(v)==3: v="".join(c*2 for c in v)
    if not re.fullmatch(r"[0-9a-fA-F]{6}",v): raise ValueError("Enter a hex color like #2D6CDF or #abc.")
    r,g,b=(int(v[i:i+2],16) for i in (0,2,4))
    h,l,s=colorsys.rgb_to_hls(r/255,g/255,b/255)
    return f"HEX: #{v.upper()}\nRGB: {r}, {g}, {b}\nHSL: {round(h*360)}°, {round(s*100)}%, {round(l*100)}%"
def decode_jwt(token):
    """Decode JWT parts for inspection only. This does NOT verify signature or trust claims."""
    parts=token.strip().split(".")
    if len(parts)!=3: raise ValueError("A compact JWT must have three dot-separated parts.")
    def decode_part(part):
        raw=base64.urlsafe_b64decode(part + "="*((-len(part))%4))
        return json.loads(raw.decode("utf-8"))
    header,payload=decode_part(parts[0]),decode_part(parts[1])
    return "JWT DECODED ONLY — SIGNATURE NOT VERIFIED\nNever trust claims based on this output.\n\nHEADER\n"+json.dumps(header,indent=2)+"\n\nPAYLOAD\n"+json.dumps(payload,indent=2)
def parse_url(value):
    p=urlparse(value.strip())
    return "\n".join([f"Scheme: {p.scheme or '(none)'}",f"Host: {p.hostname or '(none)'}",f"Port: {p.port or '(default/none)'}",
        f"Path: {p.path}",f"Fragment: {p.fragment or '(none)'}","Query parameters:"]+
        [f"  {k}: {v}" for k,vals in parse_qs(p.query,keep_blank_values=True).items() for v in vals])
def case_convert(text, mode):
    if mode=="UPPERCASE": return text.upper()
    if mode=="lowercase": return text.lower()
    if mode=="Title Case": return text.title()
    if mode=="Sentence case": return text[:1].upper()+text[1:].lower()
    if mode=="snake_case": return re.sub(r"[^A-Za-z0-9]+","_",text).strip("_").lower()
    if mode=="kebab-case": return re.sub(r"[^A-Za-z0-9]+","-",text).strip("-").lower()
    if mode=="camelCase":
        words=re.findall(r"[A-Za-z0-9]+",text)
        return (words[0].lower()+''.join(w.title() for w in words[1:])) if words else ""
    raise ValueError("Unknown case conversion.")
def html_escape(text):
    import html
    return html.escape(text)
def html_unescape(text):
    import html
    return html.unescape(text)
