"""Lioma Open Tools desktop app. Local-first developer utility workbench."""
from __future__ import annotations
import json, os, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from . import __version__
from . import core

BG="#f4f6fa"; PANEL="#ffffff"; INK="#202938"; MUTED="#667085"; BLUE="#275dad"
TOOLS=[
("Home","Welcome","Start here and see available tools."),
("JSON Formatter","Data","Format, minify, validate JSON."),
("Base64 / URL","Encoding","Encode and decode Base64 and URL components."),
("UUID Generator","Generators","Generate UUID v4 identifiers."),
("Timestamp","Time","Convert Unix timestamps and ISO dates."),
("Regex Tester","Text","Test Python regular expressions against sample text."),
("JWT Inspector","Security","Decode JWT header and claims without signature verification."),
("Hash & File Inspector","Files","Hash files and identify common file signatures."),
("Text Diff","Text","Compare two text snippets."),
("Text Case","Text","Convert text casing and naming styles."),
("Color Converter","Design","Convert HEX colors to RGB and HSL."),
("URL Parser","Web","Inspect URL components and query parameters."),
("HTML Entities","Encoding","Escape or unescape HTML entities."),
("Text Encoding","Files","Convert text file encodings without overwriting source."),
("File Info","Files","View file metadata and SHA-256."),
("Settings","App","Customize theme, font size and behavior."),
("About","App","Version, privacy notes and project information."),
]
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Lioma Open Tools")
        self.geometry("1120x760"); self.minsize(900,600)
        self.settings={"theme":"Light","font_size":10,"confirm_overwrite":True}
        self.current_tool="Home"; self.tool_buttons={}
        self._apply_theme()
        self._build_shell()
        self.show_tool("Home")
    def _apply_theme(self):
        dark=self.settings["theme"]=="Dark"
        global BG,PANEL,INK,MUTED,BLUE
        BG="#171a21" if dark else "#f4f6fa"; PANEL="#222630" if dark else "#ffffff"
        INK="#eef2f8" if dark else "#202938"; MUTED="#a3adbd" if dark else "#667085"
        BLUE="#76a7ff" if dark else "#275dad"
        self.configure(bg=BG)
    def _build_shell(self):
        self.style=ttk.Style(self)
        try:self.style.theme_use("clam")
        except tk.TclError:pass
        self.style.configure("TFrame",background=BG)
        self.style.configure("TLabel",background=BG,foreground=INK,font=("Segoe UI",self.settings["font_size"]))
        self.style.configure("TButton",padding=(10,6),font=("Segoe UI",self.settings["font_size"]))
        self.style.configure("TEntry",padding=6)
        self.style.configure("TCombobox",padding=5)
        self.style.configure("TNotebook",background=BG,borderwidth=0)
        self.style.configure("TNotebook.Tab",padding=(12,8))
        top=tk.Frame(self,bg=BG);top.pack(fill="x",padx=18,pady=(14,10))
        tk.Label(top,text="Lioma",font=("Segoe UI",22,"bold"),bg=BG,fg=BLUE).pack(side="left")
        tk.Label(top,text="OPEN TOOLS",font=("Segoe UI",10,"bold"),bg=BG,fg=INK).pack(side="left",padx=(10,0),pady=(9,0))
        self.search=tk.StringVar()
        search=ttk.Entry(top,textvariable=self.search,width=32)
        search.pack(side="left",padx=(32,8),ipady=3)
        search.insert(0,"")
        self.search.trace_add("write",lambda *_:self._render_nav())
        ttk.Button(top,text="⚙ Settings",command=lambda:self.show_tool("Settings")).pack(side="right")
        self.body=tk.Frame(self,bg=BG);self.body.pack(fill="both",expand=True,padx=18,pady=(0,12))
        self.sidebar=tk.Frame(self.body,bg=PANEL,width=220,highlightthickness=1,highlightbackground="#d8dee8")
        self.sidebar.pack(side="left",fill="y");self.sidebar.pack_propagate(False)
        tk.Label(self.sidebar,text="WORKSPACE",font=("Segoe UI",9,"bold"),bg=PANEL,fg=MUTED,anchor="w").pack(fill="x",padx=14,pady=(14,7))
        self.nav=tk.Frame(self.sidebar,bg=PANEL);self.nav.pack(fill="both",expand=True)
        right=tk.Frame(self.body,bg=BG);right.pack(side="left",fill="both",expand=True,padx=(14,0))
        self.page_head=tk.Frame(right,bg=BG);self.page_head.pack(fill="x",pady=(2,10))
        self.page_title=tk.Label(self.page_head,text="",font=("Segoe UI",20,"bold"),bg=BG,fg=INK)
        self.page_title.pack(anchor="w")
        self.page_sub=tk.Label(self.page_head,text="",font=("Segoe UI",10),bg=BG,fg=MUTED)
        self.page_sub.pack(anchor="w",pady=(2,0))
        self.content=tk.Frame(right,bg=BG);self.content.pack(fill="both",expand=True)
        self.status=tk.StringVar(value=f"Ready · v{__version__} · Local processing")
        tk.Label(self,textvariable=self.status,bg=PANEL,fg=MUTED,anchor="w",padx=18,pady=7).pack(fill="x",side="bottom")
        self._render_nav()
    def _render_nav(self):
        for w in self.nav.winfo_children():w.destroy()
        query=self.search.get().strip().lower()
        for name,category,desc in TOOLS:
            if query and query not in (name+" "+category+" "+desc).lower():continue
            b=tk.Button(self.nav,text="  "+("⚙  " if name=="Settings" else "")+name,anchor="w",
                relief="flat",bd=0,padx=10,pady=7,bg=BLUE if name==self.current_tool else PANEL,
                fg="white" if name==self.current_tool else INK,activebackground=BLUE,activeforeground="white",
                font=("Segoe UI",self.settings["font_size"]),command=lambda n=name:self.show_tool(n))
            b.pack(fill="x",padx=7,pady=1)
    def _clear(self):
        for w in self.content.winfo_children():w.destroy()
    def _heading(self,name):
        meta=next((x for x in TOOLS if x[0]==name),None)
        self.page_title.configure(text=name)
        self.page_sub.configure(text=meta[2] if meta else "")
    def _card(self,parent=None):
        f=tk.Frame(parent or self.content,bg=PANEL,highlightthickness=1,highlightbackground="#d8dee8")
        f.pack(fill="both",expand=True,pady=2)
        return f
    def _label(self,parent,text):
        tk.Label(parent,text=text,bg=PANEL,fg=INK,font=("Segoe UI",self.settings["font_size"]),anchor="w").pack(fill="x",padx=14,pady=(10,3))
    def _entry(self,parent,var=None,width=None):
        e=ttk.Entry(parent,textvariable=var,width=width);e.pack(fill="x",padx=14,pady=4);return e
    def _button(self,parent,text,command):
        b=ttk.Button(parent,text=text,command=command);b.pack(side="left",padx=(0,7),pady=8);return b
    def _text(self,parent,height=12,initial=""):
        frame=tk.Frame(parent,bg=PANEL);frame.pack(fill="both",expand=True,padx=14,pady=5)
        t=tk.Text(frame,height=height,wrap="none",font=("Consolas",self.settings["font_size"]),bg=PANEL,fg=INK,insertbackground=INK,undo=True)
        sy=ttk.Scrollbar(frame,orient="vertical",command=t.yview);sx=ttk.Scrollbar(frame,orient="horizontal",command=t.xview)
        t.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        t.grid(row=0,column=0,sticky="nsew");sy.grid(row=0,column=1,sticky="ns");sx.grid(row=1,column=0,sticky="ew")
        frame.rowconfigure(0,weight=1);frame.columnconfigure(0,weight=1)
        if initial:t.insert("1.0",initial)
        return t
    def _get(self,w):return w.get("1.0","end-1c")
    def _set(self,w,value):
        w.delete("1.0","end");w.insert("1.0",str(value))
    def _copy(self,w):
        self.clipboard_clear();self.clipboard_append(w.get("1.0","end-1c"));self.status.set("Copied to clipboard")
    def _action_row(self,parent): 
        row=tk.Frame(parent,bg=PANEL);row.pack(fill="x",padx=14,pady=4);return row
    def show_tool(self,name):
        self.current_tool=name;self._render_nav();self._clear();self._heading(name)
        route = {
            "Home": "tool_home",
            "JSON Formatter": "tool_json_formatter",
            "Base64 / URL": "tool_base64__url",
            "UUID Generator": "tool_uuid_generator",
            "Timestamp": "tool_timestamp",
            "Regex Tester": "tool_regex_tester",
            "JWT Inspector": "tool_jwt_inspector",
            "Hash & File Inspector": "tool_hash_and_file_inspector",
            "Text Diff": "tool_text_diff",
            "Text Case": "tool_text_case",
            "Color Converter": "tool_color_converter",
            "URL Parser": "tool_url_parser",
            "HTML Entities": "tool_html_entities",
            "Text Encoding": "tool_text_encoding",
            "File Info": "tool_file_info",
            "Settings": "tool_settings",
            "About": "tool_about",
        }
        method = getattr(self, route.get(name, "tool_home"), None)
        if method:
            method()
        else:
            self.tool_home()
    def tool_home(self):
        c=self._card()
        tk.Label(c,text="Small tools. Less friction.",font=("Segoe UI",22,"bold"),bg=PANEL,fg=INK).pack(anchor="w",padx=18,pady=(18,4))
        tk.Label(c,text="A local-first toolbox for the little tasks that interrupt real work.",font=("Segoe UI",11),bg=PANEL,fg=MUTED).pack(anchor="w",padx=18)
        grid=tk.Frame(c,bg=PANEL);grid.pack(fill="both",expand=True,padx=12,pady=14)
        featured=[("JSON Formatter","Format API payloads and configuration."),("Base64 / URL","Encode or decode strings."),("Hash & File Inspector","Check hashes and inspect file signatures."),("UUID Generator","Generate identifiers in bulk."),("Regex Tester","Try a pattern against sample text."),("Timestamp","Convert Unix times and ISO dates.")]
        for i,(name,desc) in enumerate(featured):
            r,col=divmod(i,2);box=tk.Frame(grid,bg=BG,padx=12,pady=12);box.grid(row=r,column=col,sticky="nsew",padx=5,pady=5)
            tk.Label(box,text=name,font=("Segoe UI",12,"bold"),bg=BG,fg=INK).pack(anchor="w")
            tk.Label(box,text=desc,wraplength=280,justify="left",bg=BG,fg=MUTED).pack(anchor="w",pady=(5,10))
            ttk.Button(box,text="Open tool →",command=lambda n=name:self.show_tool(n)).pack(anchor="w")
            grid.columnconfigure(col,weight=1);grid.rowconfigure(r,weight=1)
        tk.Label(c,text="Privacy by default: utility processing stays on this computer. Network features are not included in this MVP.",bg=PANEL,fg=MUTED,wraplength=650,justify="left").pack(anchor="w",padx=18,pady=(0,15))
    def tool_json_formatter(self):
        c=self._card();self._label(c,"JSON input");src=self._text(c,10,'{"name":"Lioma","tools":["json","hash"]}')
        row=self._action_row(c);out=self._text(c,10)
        indent=tk.StringVar(value="2")
        ttk.Label(row,text="Indent").pack(side="left")
        ttk.Combobox(row,textvariable=indent,values=["2","4","tab"],width=7,state="readonly").pack(side="left",padx=5)
        def run(minify=False):
            try:
                val=json.loads(self._get(src));pretty=json.dumps(val,ensure_ascii=False,sort_keys=False,separators=(",",":") if minify else None,indent=None if minify else ("\t" if indent.get()=="tab" else int(indent.get())))
                self._set(out,pretty);self.status.set("Valid JSON · formatted")
            except Exception as e:messagebox.showerror("Invalid JSON",str(e))
        self._button(row,"Format / Validate",lambda:run(False));self._button(row,"Minify",lambda:run(True));self._button(row,"Copy output",lambda:self._copy(out))
    def tool_base64__url(self):
        c=self._card();self._label(c,"Input text");src=self._text(c,8)
        row=self._action_row(c);urlsafe=tk.BooleanVar(value=False)
        ttk.Checkbutton(row,text="Base64URL alphabet",variable=urlsafe).pack(side="left",padx=(0,8))
        out=self._text(c,8)
        def act(fn):
            try:self._set(out,fn(self._get(src)));self.status.set("Done")
            except Exception as e:messagebox.showerror("Conversion failed",str(e))
        self._button(row,"Base64 Encode",lambda:act(lambda s:core.base64_encode(s,urlsafe.get())))
        self._button(row,"Base64 Decode",lambda:act(lambda s:core.base64_decode(s,urlsafe.get())))
        self._button(row,"URL Encode",lambda:act(core.url_encode));self._button(row,"URL Decode",lambda:act(core.url_decode));self._button(row,"Copy",lambda:self._copy(out))
    def tool_uuid_generator(self):
        c=self._card();row=self._action_row(c);count=tk.StringVar(value="10")
        ttk.Label(row,text="Count (1–1000)").pack(side="left");ttk.Entry(row,textvariable=count,width=8).pack(side="left",padx=6)
        out=self._text(c,18)
        def gen():
            try:self._set(out,core.make_uuids(int(count.get())));self.status.set("UUIDs generated")
            except Exception as e:messagebox.showerror("Invalid count",str(e))
        self._button(row,"Generate UUID v4",gen);self._button(row,"Copy",lambda:self._copy(out))
    def tool_timestamp(self):
        c=self._card();self._label(c,"Unix timestamp");value=tk.StringVar();self._entry(c,value)
        row=self._action_row(c);unit=tk.StringVar(value="seconds")
        ttk.Combobox(row,textvariable=unit,values=["seconds","milliseconds"],state="readonly",width=15).pack(side="left",padx=(0,8))
        out=self._text(c,5)
        def to_date():
            try:self._set(out,core.timestamp_convert(value.get(),unit.get()))
            except Exception as e:messagebox.showerror("Invalid timestamp",str(e))
        self._button(row,"Timestamp → UTC date",to_date)
        self._label(c,"ISO date (include timezone when known; naive dates are treated as UTC)");iso=tk.StringVar();self._entry(c,iso)
        row2=self._action_row(c);out2=self._text(c,3)
        def to_epoch():
            try:self._set(out2,core.iso_to_timestamp(iso.get(),unit.get()))
            except Exception as e:messagebox.showerror("Invalid date",str(e))
        self._button(row2,"ISO date → timestamp",to_epoch);self._button(row2,"Copy result",lambda:self._copy(out2))
    def tool_regex_tester(self):
        c=self._card();self._label(c,"Regular expression");pat=tk.StringVar(value=r"\bLioma\b");self._entry(c,pat)
        row=self._action_row(c);flags=tk.StringVar(value="i")
        ttk.Label(row,text="Flags (i, m, s)").pack(side="left");ttk.Entry(row,textvariable=flags,width=8).pack(side="left",padx=6)
        self._label(c,"Test text");src=self._text(c,8,"Lioma Open Tools\nlioma utilities\nAnother line")
        out=self._text(c,8)
        def run():
            try:self._set(out,core.regex_test(pat.get(),self._get(src),flags.get()));self.status.set("Regex tested")
            except Exception as e:messagebox.showerror("Regex error",str(e))
        row2=self._action_row(c);self._button(row2,"Run test",run);self._button(row2,"Copy results",lambda:self._copy(out))
    def tool_jwt_inspector(self):
        c=self._card()
        tk.Label(c,text="⚠ Decode only: this does NOT verify the token signature or make claims trustworthy.",bg="#fff1d6",fg="#7a4b00",wraplength=700,justify="left",padx=12,pady=10).pack(fill="x",padx=14,pady=12)
        self._label(c,"JWT token");src=self._text(c,5)
        row=self._action_row(c);out=self._text(c,13)
        def run():
            try:self._set(out,core.decode_jwt(self._get(src)));self.status.set("Decoded locally · not verified")
            except Exception as e:messagebox.showerror("JWT decode failed",str(e))
        self._button(row,"Decode header and payload",run);self._button(row,"Copy output",lambda:self._copy(out))
    def tool_hash_and_file_inspector(self):
        c=self._card();row=self._action_row(c);path=tk.StringVar()
        ttk.Entry(row,textvariable=path).pack(side="left",fill="x",expand=True,padx=(0,6))
        out=self._text(c,18)
        def browse():
            p=filedialog.askopenfilename()
            if p:path.set(p)
        self._button(row,"Browse…",browse)
        alg=tk.StringVar(value="sha256");ttk.Combobox(row,textvariable=alg,values=["sha256","sha512","sha1","md5"],width=9,state="readonly").pack(side="left",padx=4)
        def inspect():
            try:
                p=path.get()
                result=core.identify_file(p);info=core.file_info(p)
                self._set(out,"\n".join([f"{k}: {v}" for k,v in result.items()]+["",*[f"{k}: {v}" for k,v in info.items()],"",f"{alg.get().upper()}: {core.hash_file(p,alg.get())}"]))
                self.status.set("File inspected and hashed")
            except Exception as e:messagebox.showerror("Inspection failed",str(e))
        self._button(row,"Inspect + Hash",inspect);self._button(row,"Copy report",lambda:self._copy(out))
    def tool_text_diff(self):
        c=self._card();self._label(c,"Left text");a=self._text(c,7);self._label(c,"Right text");b=self._text(c,7);out=self._text(c,8)
        row=self._action_row(c)
        self._button(row,"Compare",lambda:self._set(out,core.text_diff(self._get(a),self._get(b))))
        self._button(row,"Copy diff",lambda:self._copy(out))
    def tool_text_case(self):
        c=self._card();self._label(c,"Input text");src=self._text(c,10)
        row=self._action_row(c);mode=tk.StringVar(value="camelCase")
        ttk.Combobox(row,textvariable=mode,values=["UPPERCASE","lowercase","Title Case","Sentence case","snake_case","kebab-case","camelCase"],state="readonly",width=18).pack(side="left",padx=(0,8))
        out=self._text(c,10)
        def run():self._set(out,core.case_convert(self._get(src),mode.get()))
        self._button(row,"Convert",run);self._button(row,"Copy output",lambda:self._copy(out))
    def tool_color_converter(self):
        c=self._card();self._label(c,"HEX color");value=tk.StringVar(value="#275dad");self._entry(c,value)
        row=self._action_row(c);out=self._text(c,8)
        def run():
            try:self._set(out,core.color_convert(value.get()));self.status.set("Color converted")
            except Exception as e:messagebox.showerror("Invalid color",str(e))
        self._button(row,"Convert HEX → RGB / HSL",run);self._button(row,"Copy",lambda:self._copy(out))
    def tool_url_parser(self):
        c=self._card();self._label(c,"URL");value=tk.StringVar(value="https://example.com/path?query=hello%20world&mode=debug#top");self._entry(c,value)
        row=self._action_row(c);out=self._text(c,15)
        def run():
            try:self._set(out,core.parse_url(value.get()))
            except Exception as e:messagebox.showerror("URL error",str(e))
        self._button(row,"Parse URL",run);self._button(row,"Copy",lambda:self._copy(out))
    def tool_html_entities(self):
        c=self._card();self._label(c,"Input text");src=self._text(c,10,'<div class="hello">Tom & Jerry</div>')
        row=self._action_row(c);out=self._text(c,10)
        self._button(row,"Escape HTML",lambda:self._set(out,core.html_escape(self._get(src))))
        self._button(row,"Unescape HTML",lambda:self._set(out,core.html_unescape(self._get(src))))
        self._button(row,"Copy",lambda:self._copy(out))
    def tool_text_encoding(self):
        c=self._card();src=tk.StringVar();dst=tk.StringVar()
        row=self._action_row(c);ttk.Entry(row,textvariable=src).pack(side="left",fill="x",expand=True,padx=(0,5))
        self._button(row,"Choose source",lambda:src.set(filedialog.askopenfilename()))
        row2=self._action_row(c);ttk.Entry(row2,textvariable=dst).pack(side="left",fill="x",expand=True,padx=(0,5))
        self._button(row2,"Save as…",lambda:dst.set(filedialog.asksaveasfilename()))
        row3=self._action_row(c);frm=tk.StringVar(value="utf-8");to=tk.StringVar(value="utf-8")
        ttk.Label(row3,text="Read as").pack(side="left");ttk.Entry(row3,textvariable=frm,width=14).pack(side="left",padx=5)
        ttk.Label(row3,text="Write as").pack(side="left");ttk.Entry(row3,textvariable=to,width=14).pack(side="left",padx=5)
        def run():
            try:
                if Path(dst.get()).exists() and not messagebox.askyesno("Overwrite?","Destination exists. Replace it?"):return
                core.convert_encoding(src.get(),dst.get(),frm.get(),to.get());messagebox.showinfo("Done",f"Saved to {dst.get()}")
            except Exception as e:messagebox.showerror("Conversion failed",str(e))
        self._button(row3,"Convert",run)
        tk.Label(c,text="The source file is never overwritten. Common encodings: utf-8, utf-8-sig, cp1252, latin-1.",bg=PANEL,fg=MUTED).pack(anchor="w",padx=14,pady=10)
    def tool_file_info(self):
        c=self._card();row=self._action_row(c);path=tk.StringVar();ttk.Entry(row,textvariable=path).pack(side="left",fill="x",expand=True,padx=(0,5))
        out=self._text(c,18)
        def browse(): 
            p=filedialog.askopenfilename()
            if p:path.set(p)
        self._button(row,"Browse…",browse)
        def run():
            try:self._set(out,"\n".join(f"{k}: {v}" for k,v in core.file_info(path.get()).items()))
            except Exception as e:messagebox.showerror("File info failed",str(e))
        self._button(row,"Get info",run);self._button(row,"Copy",lambda:self._copy(out))
    def tool_settings(self):
        c=self._card()
        self._label(c,"Appearance")
        row=self._action_row(c);theme=tk.StringVar(value=self.settings["theme"])
        ttk.Label(row,text="Theme").pack(side="left");ttk.Combobox(row,textvariable=theme,values=["Light","Dark"],state="readonly",width=12).pack(side="left",padx=8)
        size=tk.StringVar(value=str(self.settings["font_size"]))
        ttk.Label(row,text="Font size").pack(side="left",padx=(20,0));ttk.Combobox(row,textvariable=size,values=["9","10","11","12","13"],state="readonly",width=6).pack(side="left",padx=8)
        confirm=tk.BooleanVar(value=self.settings["confirm_overwrite"])
        ttk.Checkbutton(c,text="Ask before overwriting existing destination files",variable=confirm).pack(anchor="w",padx=14,pady=10)
        tk.Label(c,text="Privacy",bg=PANEL,fg=INK,font=("Segoe UI",12,"bold")).pack(anchor="w",padx=14,pady=(18,4))
        tk.Label(c,text="Lioma Open Tools processes utility inputs locally. It does not upload data or make network requests in this version. JWT inspection decodes data only; it never verifies signatures.",bg=PANEL,fg=MUTED,wraplength=650,justify="left").pack(anchor="w",padx=14)
        row2=self._action_row(c)
        def save():
            self.settings.update(theme=theme.get(),font_size=int(size.get()),confirm_overwrite=confirm.get())
            self._apply_theme();self._build_shell();self.show_tool("Settings")
            messagebox.showinfo("Settings applied","Appearance settings applied for this session.")
        self._button(row2,"Apply settings",save)
        self._button(row2,"Reset defaults",lambda:self._reset_settings())
        tk.Label(c,text="Settings currently apply for this session; persistent preferences are planned for a later version.",bg=PANEL,fg=MUTED).pack(anchor="w",padx=14,pady=12)
    def _reset_settings(self):
        self.settings={"theme":"Light","font_size":10,"confirm_overwrite":True}
        self._apply_theme();self._build_shell();self.show_tool("Settings")
    def tool_about(self):
        c=self._card()
        tk.Label(c,text="Lioma Open Tools",font=("Segoe UI",22,"bold"),bg=PANEL,fg=BLUE).pack(anchor="w",padx=18,pady=(20,4))
        tk.Label(c,text=f"Version {__version__} · Free and open source · MIT License",bg=PANEL,fg=INK).pack(anchor="w",padx=18)
        tk.Label(c,text="A local-first collection of small utilities for developers, students, and curious people. No account, ads, telemetry, or cloud processing in this MVP.",bg=PANEL,fg=MUTED,wraplength=650,justify="left").pack(anchor="w",padx=18,pady=14)
        ttk.Button(c,text="Open Settings",command=lambda:self.show_tool("Settings")).pack(anchor="w",padx=18)
        tk.Label(c,text="Important: file signature checks are not antivirus. JWT decoding does not verify signatures. Treat decoded secrets as sensitive.",bg=PANEL,fg="#9a5b00",wraplength=650,justify="left").pack(anchor="w",padx=18,pady=18)
def main():
    app=App();app.mainloop()
if __name__=="__main__":main()
