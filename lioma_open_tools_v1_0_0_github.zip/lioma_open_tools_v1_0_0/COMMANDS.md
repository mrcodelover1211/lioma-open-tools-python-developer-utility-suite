# Lioma Open Tools: Commands and Setup

This is the main step-by-step command guide for setting up, launching, testing, and creating a Windows desktop shortcut for Lioma Open Tools.

## Requirements

- Python 3.10 or newer
- Tkinter, which is included with most standard Windows Python installations
- No third-party Python packages are required
- Windows desktop shortcut creation requires Windows PowerShell, normally included with Windows

## 1. Download and extract

1. Download the Lioma Open Tools ZIP from the GitHub repository's **Code → Download ZIP** menu, or from the project's Releases section.
2. Extract the ZIP to a folder you can keep in place, such as `Documents\LiomaOpenTools`.
3. Open that extracted folder in File Explorer.

Keep the folder in the same location after creating the desktop shortcut. If you move or delete it, the shortcut will need to be recreated.

## 2. Check Python

Open PowerShell in the extracted project folder. In File Explorer, click the address bar, type `powershell`, and press Enter. Then run:

```powershell
py --version
```

If the `py` command is unavailable, try:

```powershell
python --version
```

The version must be Python 3.10 or newer. If neither command works, install Python from <https://www.python.org/downloads/> and enable the Python launcher option if offered.

## 3. Launch Lioma Open Tools

From the project folder, run:

```powershell
py -m lioma_open_tools
```

If your system does not have the `py` launcher but `python` works, run:

```powershell
python -m lioma_open_tools
```

No `pip install` command is needed for the source ZIP. The app uses Python's standard library.

## 4. Create a Windows desktop shortcut

Run this once from the extracted project folder:

```powershell
py install_shortcut.py
```

Or, if you use `python` instead of `py`:

```powershell
python install_shortcut.py
```

The script creates or updates `Lioma Open Tools.lnk` on your Windows desktop. It does not require administrator permissions and does not install an EXE. It uses `pythonw.exe` when available so the app can launch without a console window. If you move the project folder later, run the script again from its new location.

## 5. Run the tests

From the project folder:

```powershell
py -m unittest discover -s tests -v
```

Alternative:

```powershell
python -m unittest discover -s tests -v
```

## 6. Check Python syntax

```powershell
py -m compileall -q lioma_open_tools install_shortcut.py tests
```

## 7. GitHub repository description

Paste this into the short **Description** field in the GitHub repository's About section (this is not the README):

> Free, open-source Python developer toolbox. Open `COMMANDS.md` for all commands, setup instructions, launch steps, testing, and Windows desktop shortcut installation.

## 8. Publish the source ZIP on GitHub without installing Git

1. Sign in to GitHub and open your repository.
2. Choose **Add file → Upload files**.
3. Upload the project files and folders from the extracted project directory. GitHub's web uploader can upload files, but uploading a ZIP alone does not turn the ZIP's contents into browsable source files.
4. Commit the upload using GitHub's on-screen form.
5. To publish a downloadable release, open **Releases → Draft a new release**.
6. Create a tag named `v1.0.0`, set the release title to `Lioma Open Tools v1.0.0`, add release notes, and attach the project ZIP as a release asset if it is not already available there.
7. Publish the release. Visitors can then download the source ZIP from the release page.

You do not need to install Git to use GitHub's web upload and release pages. For a clean repository, upload the extracted project contents, not the outer ZIP as the only repository file.

## Troubleshooting

- **`py` is not recognized:** try `python`; if neither works, install Python 3.10+.
- **Tkinter error:** install/reinstall Python using the official Windows installer and ensure Tcl/Tk support is included.
- **Shortcut does not open after moving the folder:** run `py install_shortcut.py` again from the new folder.
- **Shortcut opens a console:** the Python installation may not include `pythonw.exe`; the shortcut script will use the regular Python executable as a fallback.
- **The app does not launch:** open PowerShell in the project folder and run `py -m lioma_open_tools` to see any error output.

## Privacy note

Lioma Open Tools is designed for local processing and does not make network requests or use telemetry in this version. Some tools display sensitive text locally, so do not share screenshots or logs containing secrets.
